.. currentmodule:: dds_cloudapi_sdk.config

Client
================================

.. automodule:: dds_cloudapi_sdk.client
   :no-members:

API Reference
-------------

.. autoclass:: Client
   :members:
   :exclude-members: __init__
   :inherited-members:
