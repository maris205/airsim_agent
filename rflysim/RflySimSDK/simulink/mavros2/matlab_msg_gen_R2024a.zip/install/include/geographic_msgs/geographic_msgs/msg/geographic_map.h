// generated from rosidl_generator_c/resource/idl.h.em
// with input from geographic_msgs:msg\GeographicMap.idl
// generated code does not contain a copyright notice

#ifndef GEOGRAPHIC_MSGS__MSG__GEOGRAPHIC_MAP_H_
#define GEOGRAPHIC_MSGS__MSG__GEOGRAPHIC_MAP_H_

#include "geographic_msgs/msg/detail/geographic_map__struct.h"
#include "geographic_msgs/msg/detail/geographic_map__functions.h"
#include "geographic_msgs/msg/detail/geographic_map__type_support.h"

#endif  // GEOGRAPHIC_MSGS__MSG__GEOGRAPHIC_MAP_H_
