// generated from rosidl_generator_c/resource/idl.h.em
// with input from geographic_msgs:msg\KeyValue.idl
// generated code does not contain a copyright notice

#ifndef GEOGRAPHIC_MSGS__MSG__KEY_VALUE_H_
#define GEOGRAPHIC_MSGS__MSG__KEY_VALUE_H_

#include "geographic_msgs/msg/detail/key_value__struct.h"
#include "geographic_msgs/msg/detail/key_value__functions.h"
#include "geographic_msgs/msg/detail/key_value__type_support.h"

#endif  // GEOGRAPHIC_MSGS__MSG__KEY_VALUE_H_
