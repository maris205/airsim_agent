// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef GEOGRAPHIC_MSGS__MSG__KEY_VALUE_HPP_
#define GEOGRAPHIC_MSGS__MSG__KEY_VALUE_HPP_

#include "geographic_msgs/msg/detail/key_value__struct.hpp"
#include "geographic_msgs/msg/detail/key_value__builder.hpp"
#include "geographic_msgs/msg/detail/key_value__traits.hpp"

#endif  // GEOGRAPHIC_MSGS__MSG__KEY_VALUE_HPP_
