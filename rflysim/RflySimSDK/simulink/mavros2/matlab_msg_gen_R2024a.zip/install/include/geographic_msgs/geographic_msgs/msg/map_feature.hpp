// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef GEOGRAPHIC_MSGS__MSG__MAP_FEATURE_HPP_
#define GEOGRAPHIC_MSGS__MSG__MAP_FEATURE_HPP_

#include "geographic_msgs/msg/detail/map_feature__struct.hpp"
#include "geographic_msgs/msg/detail/map_feature__builder.hpp"
#include "geographic_msgs/msg/detail/map_feature__traits.hpp"

#endif  // GEOGRAPHIC_MSGS__MSG__MAP_FEATURE_HPP_
