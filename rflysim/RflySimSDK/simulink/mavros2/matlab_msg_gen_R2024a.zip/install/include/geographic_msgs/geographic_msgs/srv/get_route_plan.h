// generated from rosidl_generator_c/resource/idl.h.em
// with input from geographic_msgs:srv\GetRoutePlan.idl
// generated code does not contain a copyright notice

#ifndef GEOGRAPHIC_MSGS__SRV__GET_ROUTE_PLAN_H_
#define GEOGRAPHIC_MSGS__SRV__GET_ROUTE_PLAN_H_

#include "geographic_msgs/srv/detail/get_route_plan__struct.h"
#include "geographic_msgs/srv/detail/get_route_plan__functions.h"
#include "geographic_msgs/srv/detail/get_route_plan__type_support.h"

#endif  // GEOGRAPHIC_MSGS__SRV__GET_ROUTE_PLAN_H_
