// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:msg\ADSBVehicle.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__ADSB_VEHICLE_H_
#define MAVROS_MSGS__MSG__ADSB_VEHICLE_H_

#include "mavros_msgs/msg/detail/adsb_vehicle__struct.h"
#include "mavros_msgs/msg/detail/adsb_vehicle__functions.h"
#include "mavros_msgs/msg/detail/adsb_vehicle__type_support.h"

#endif  // MAVROS_MSGS__MSG__ADSB_VEHICLE_H_
