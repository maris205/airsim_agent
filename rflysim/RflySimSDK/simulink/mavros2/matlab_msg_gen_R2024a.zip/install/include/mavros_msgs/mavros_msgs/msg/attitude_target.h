// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:msg\AttitudeTarget.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__ATTITUDE_TARGET_H_
#define MAVROS_MSGS__MSG__ATTITUDE_TARGET_H_

#include "mavros_msgs/msg/detail/attitude_target__struct.h"
#include "mavros_msgs/msg/detail/attitude_target__functions.h"
#include "mavros_msgs/msg/detail/attitude_target__type_support.h"

#endif  // MAVROS_MSGS__MSG__ATTITUDE_TARGET_H_
