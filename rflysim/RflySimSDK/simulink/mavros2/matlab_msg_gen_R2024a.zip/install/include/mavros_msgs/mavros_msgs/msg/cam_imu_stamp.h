// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:msg\CamIMUStamp.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__CAM_IMU_STAMP_H_
#define MAVROS_MSGS__MSG__CAM_IMU_STAMP_H_

#include "mavros_msgs/msg/detail/cam_imu_stamp__struct.h"
#include "mavros_msgs/msg/detail/cam_imu_stamp__functions.h"
#include "mavros_msgs/msg/detail/cam_imu_stamp__type_support.h"

#endif  // MAVROS_MSGS__MSG__CAM_IMU_STAMP_H_
