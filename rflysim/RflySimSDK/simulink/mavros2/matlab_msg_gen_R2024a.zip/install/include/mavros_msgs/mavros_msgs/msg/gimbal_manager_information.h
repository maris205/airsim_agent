// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:msg\GimbalManagerInformation.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__GIMBAL_MANAGER_INFORMATION_H_
#define MAVROS_MSGS__MSG__GIMBAL_MANAGER_INFORMATION_H_

#include "mavros_msgs/msg/detail/gimbal_manager_information__struct.h"
#include "mavros_msgs/msg/detail/gimbal_manager_information__functions.h"
#include "mavros_msgs/msg/detail/gimbal_manager_information__type_support.h"

#endif  // MAVROS_MSGS__MSG__GIMBAL_MANAGER_INFORMATION_H_
