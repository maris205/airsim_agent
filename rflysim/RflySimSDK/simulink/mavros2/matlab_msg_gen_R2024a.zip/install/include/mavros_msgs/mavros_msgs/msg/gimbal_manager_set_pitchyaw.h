// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:msg\GimbalManagerSetPitchyaw.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__GIMBAL_MANAGER_SET_PITCHYAW_H_
#define MAVROS_MSGS__MSG__GIMBAL_MANAGER_SET_PITCHYAW_H_

#include "mavros_msgs/msg/detail/gimbal_manager_set_pitchyaw__struct.h"
#include "mavros_msgs/msg/detail/gimbal_manager_set_pitchyaw__functions.h"
#include "mavros_msgs/msg/detail/gimbal_manager_set_pitchyaw__type_support.h"

#endif  // MAVROS_MSGS__MSG__GIMBAL_MANAGER_SET_PITCHYAW_H_
