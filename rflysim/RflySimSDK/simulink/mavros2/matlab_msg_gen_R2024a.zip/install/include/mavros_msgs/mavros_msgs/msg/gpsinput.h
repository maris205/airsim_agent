// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:msg\GPSINPUT.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__GPSINPUT_H_
#define MAVROS_MSGS__MSG__GPSINPUT_H_

#include "mavros_msgs/msg/detail/gpsinput__struct.h"
#include "mavros_msgs/msg/detail/gpsinput__functions.h"
#include "mavros_msgs/msg/detail/gpsinput__type_support.h"

#endif  // MAVROS_MSGS__MSG__GPSINPUT_H_
