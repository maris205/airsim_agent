// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:msg\Mavlink.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__MAVLINK_H_
#define MAVROS_MSGS__MSG__MAVLINK_H_

#include "mavros_msgs/msg/detail/mavlink__struct.h"
#include "mavros_msgs/msg/detail/mavlink__functions.h"
#include "mavros_msgs/msg/detail/mavlink__type_support.h"

#endif  // MAVROS_MSGS__MSG__MAVLINK_H_
