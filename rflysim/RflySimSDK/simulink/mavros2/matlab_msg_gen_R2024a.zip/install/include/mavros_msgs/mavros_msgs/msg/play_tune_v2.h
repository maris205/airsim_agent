// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:msg\PlayTuneV2.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__PLAY_TUNE_V2_H_
#define MAVROS_MSGS__MSG__PLAY_TUNE_V2_H_

#include "mavros_msgs/msg/detail/play_tune_v2__struct.h"
#include "mavros_msgs/msg/detail/play_tune_v2__functions.h"
#include "mavros_msgs/msg/detail/play_tune_v2__type_support.h"

#endif  // MAVROS_MSGS__MSG__PLAY_TUNE_V2_H_
