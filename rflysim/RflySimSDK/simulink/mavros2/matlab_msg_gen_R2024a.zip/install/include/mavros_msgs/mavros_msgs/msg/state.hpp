// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__STATE_HPP_
#define MAVROS_MSGS__MSG__STATE_HPP_

#include "mavros_msgs/msg/detail/state__struct.hpp"
#include "mavros_msgs/msg/detail/state__builder.hpp"
#include "mavros_msgs/msg/detail/state__traits.hpp"

#endif  // MAVROS_MSGS__MSG__STATE_HPP_
