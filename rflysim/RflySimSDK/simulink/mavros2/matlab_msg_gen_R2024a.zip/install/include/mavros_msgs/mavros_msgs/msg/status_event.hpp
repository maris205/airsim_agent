// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__STATUS_EVENT_HPP_
#define MAVROS_MSGS__MSG__STATUS_EVENT_HPP_

#include "mavros_msgs/msg/detail/status_event__struct.hpp"
#include "mavros_msgs/msg/detail/status_event__builder.hpp"
#include "mavros_msgs/msg/detail/status_event__traits.hpp"

#endif  // MAVROS_MSGS__MSG__STATUS_EVENT_HPP_
