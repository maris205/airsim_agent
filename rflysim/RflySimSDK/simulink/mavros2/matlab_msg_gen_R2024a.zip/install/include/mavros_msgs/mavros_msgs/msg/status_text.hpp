// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__STATUS_TEXT_HPP_
#define MAVROS_MSGS__MSG__STATUS_TEXT_HPP_

#include "mavros_msgs/msg/detail/status_text__struct.hpp"
#include "mavros_msgs/msg/detail/status_text__builder.hpp"
#include "mavros_msgs/msg/detail/status_text__traits.hpp"

#endif  // MAVROS_MSGS__MSG__STATUS_TEXT_HPP_
