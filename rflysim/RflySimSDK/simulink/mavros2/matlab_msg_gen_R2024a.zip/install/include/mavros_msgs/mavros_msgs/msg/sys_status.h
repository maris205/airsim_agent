// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:msg\SysStatus.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__SYS_STATUS_H_
#define MAVROS_MSGS__MSG__SYS_STATUS_H_

#include "mavros_msgs/msg/detail/sys_status__struct.h"
#include "mavros_msgs/msg/detail/sys_status__functions.h"
#include "mavros_msgs/msg/detail/sys_status__type_support.h"

#endif  // MAVROS_MSGS__MSG__SYS_STATUS_H_
