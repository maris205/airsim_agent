// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:srv\CommandInt.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__COMMAND_INT_H_
#define MAVROS_MSGS__SRV__COMMAND_INT_H_

#include "mavros_msgs/srv/detail/command_int__struct.h"
#include "mavros_msgs/srv/detail/command_int__functions.h"
#include "mavros_msgs/srv/detail/command_int__type_support.h"

#endif  // MAVROS_MSGS__SRV__COMMAND_INT_H_
