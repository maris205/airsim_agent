// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:srv\CommandVtolTransition.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__COMMAND_VTOL_TRANSITION_H_
#define MAVROS_MSGS__SRV__COMMAND_VTOL_TRANSITION_H_

#include "mavros_msgs/srv/detail/command_vtol_transition__struct.h"
#include "mavros_msgs/srv/detail/command_vtol_transition__functions.h"
#include "mavros_msgs/srv/detail/command_vtol_transition__type_support.h"

#endif  // MAVROS_MSGS__SRV__COMMAND_VTOL_TRANSITION_H_
