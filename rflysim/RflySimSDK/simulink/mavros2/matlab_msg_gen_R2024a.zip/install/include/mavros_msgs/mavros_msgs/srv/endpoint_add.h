// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:srv\EndpointAdd.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__ENDPOINT_ADD_H_
#define MAVROS_MSGS__SRV__ENDPOINT_ADD_H_

#include "mavros_msgs/srv/detail/endpoint_add__struct.h"
#include "mavros_msgs/srv/detail/endpoint_add__functions.h"
#include "mavros_msgs/srv/detail/endpoint_add__type_support.h"

#endif  // MAVROS_MSGS__SRV__ENDPOINT_ADD_H_
