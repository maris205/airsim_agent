// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:srv\EndpointDel.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__ENDPOINT_DEL_H_
#define MAVROS_MSGS__SRV__ENDPOINT_DEL_H_

#include "mavros_msgs/srv/detail/endpoint_del__struct.h"
#include "mavros_msgs/srv/detail/endpoint_del__functions.h"
#include "mavros_msgs/srv/detail/endpoint_del__type_support.h"

#endif  // MAVROS_MSGS__SRV__ENDPOINT_DEL_H_
