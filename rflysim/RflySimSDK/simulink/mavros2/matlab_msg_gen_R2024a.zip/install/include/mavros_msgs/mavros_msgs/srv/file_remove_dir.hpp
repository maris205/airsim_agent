// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__FILE_REMOVE_DIR_HPP_
#define MAVROS_MSGS__SRV__FILE_REMOVE_DIR_HPP_

#include "mavros_msgs/srv/detail/file_remove_dir__struct.hpp"
#include "mavros_msgs/srv/detail/file_remove_dir__builder.hpp"
#include "mavros_msgs/srv/detail/file_remove_dir__traits.hpp"

#endif  // MAVROS_MSGS__SRV__FILE_REMOVE_DIR_HPP_
