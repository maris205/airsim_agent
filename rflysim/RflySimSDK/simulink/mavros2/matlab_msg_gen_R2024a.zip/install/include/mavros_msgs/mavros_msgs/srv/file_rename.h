// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:srv\FileRename.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__FILE_RENAME_H_
#define MAVROS_MSGS__SRV__FILE_RENAME_H_

#include "mavros_msgs/srv/detail/file_rename__struct.h"
#include "mavros_msgs/srv/detail/file_rename__functions.h"
#include "mavros_msgs/srv/detail/file_rename__type_support.h"

#endif  // MAVROS_MSGS__SRV__FILE_RENAME_H_
