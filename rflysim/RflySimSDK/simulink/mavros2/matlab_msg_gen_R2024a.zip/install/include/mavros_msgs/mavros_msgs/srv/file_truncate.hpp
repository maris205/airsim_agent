// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__FILE_TRUNCATE_HPP_
#define MAVROS_MSGS__SRV__FILE_TRUNCATE_HPP_

#include "mavros_msgs/srv/detail/file_truncate__struct.hpp"
#include "mavros_msgs/srv/detail/file_truncate__builder.hpp"
#include "mavros_msgs/srv/detail/file_truncate__traits.hpp"

#endif  // MAVROS_MSGS__SRV__FILE_TRUNCATE_HPP_
