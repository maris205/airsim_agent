// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__GIMBAL_GET_INFORMATION_HPP_
#define MAVROS_MSGS__SRV__GIMBAL_GET_INFORMATION_HPP_

#include "mavros_msgs/srv/detail/gimbal_get_information__struct.hpp"
#include "mavros_msgs/srv/detail/gimbal_get_information__builder.hpp"
#include "mavros_msgs/srv/detail/gimbal_get_information__traits.hpp"

#endif  // MAVROS_MSGS__SRV__GIMBAL_GET_INFORMATION_HPP_
