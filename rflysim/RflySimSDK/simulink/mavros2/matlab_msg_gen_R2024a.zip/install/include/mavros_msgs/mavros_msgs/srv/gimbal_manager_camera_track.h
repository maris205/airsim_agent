// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:srv\GimbalManagerCameraTrack.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__GIMBAL_MANAGER_CAMERA_TRACK_H_
#define MAVROS_MSGS__SRV__GIMBAL_MANAGER_CAMERA_TRACK_H_

#include "mavros_msgs/srv/detail/gimbal_manager_camera_track__struct.h"
#include "mavros_msgs/srv/detail/gimbal_manager_camera_track__functions.h"
#include "mavros_msgs/srv/detail/gimbal_manager_camera_track__type_support.h"

#endif  // MAVROS_MSGS__SRV__GIMBAL_MANAGER_CAMERA_TRACK_H_
