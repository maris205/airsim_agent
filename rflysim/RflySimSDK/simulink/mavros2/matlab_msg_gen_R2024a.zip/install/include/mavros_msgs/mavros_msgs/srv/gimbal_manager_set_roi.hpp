// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__GIMBAL_MANAGER_SET_ROI_HPP_
#define MAVROS_MSGS__SRV__GIMBAL_MANAGER_SET_ROI_HPP_

#include "mavros_msgs/srv/detail/gimbal_manager_set_roi__struct.hpp"
#include "mavros_msgs/srv/detail/gimbal_manager_set_roi__builder.hpp"
#include "mavros_msgs/srv/detail/gimbal_manager_set_roi__traits.hpp"

#endif  // MAVROS_MSGS__SRV__GIMBAL_MANAGER_SET_ROI_HPP_
