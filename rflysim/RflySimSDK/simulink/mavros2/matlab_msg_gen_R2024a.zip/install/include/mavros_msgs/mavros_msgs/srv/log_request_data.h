// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:srv\LogRequestData.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__LOG_REQUEST_DATA_H_
#define MAVROS_MSGS__SRV__LOG_REQUEST_DATA_H_

#include "mavros_msgs/srv/detail/log_request_data__struct.h"
#include "mavros_msgs/srv/detail/log_request_data__functions.h"
#include "mavros_msgs/srv/detail/log_request_data__type_support.h"

#endif  // MAVROS_MSGS__SRV__LOG_REQUEST_DATA_H_
