// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:srv\MountConfigure.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__MOUNT_CONFIGURE_H_
#define MAVROS_MSGS__SRV__MOUNT_CONFIGURE_H_

#include "mavros_msgs/srv/detail/mount_configure__struct.h"
#include "mavros_msgs/srv/detail/mount_configure__functions.h"
#include "mavros_msgs/srv/detail/mount_configure__type_support.h"

#endif  // MAVROS_MSGS__SRV__MOUNT_CONFIGURE_H_
