// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:srv\SetMode.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__SET_MODE_H_
#define MAVROS_MSGS__SRV__SET_MODE_H_

#include "mavros_msgs/srv/detail/set_mode__struct.h"
#include "mavros_msgs/srv/detail/set_mode__functions.h"
#include "mavros_msgs/srv/detail/set_mode__type_support.h"

#endif  // MAVROS_MSGS__SRV__SET_MODE_H_
