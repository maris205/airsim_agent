// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:srv\WaypointClear.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__WAYPOINT_CLEAR_H_
#define MAVROS_MSGS__SRV__WAYPOINT_CLEAR_H_

#include "mavros_msgs/srv/detail/waypoint_clear__struct.h"
#include "mavros_msgs/srv/detail/waypoint_clear__functions.h"
#include "mavros_msgs/srv/detail/waypoint_clear__type_support.h"

#endif  // MAVROS_MSGS__SRV__WAYPOINT_CLEAR_H_
