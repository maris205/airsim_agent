// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:srv\WaypointPush.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__WAYPOINT_PUSH_H_
#define MAVROS_MSGS__SRV__WAYPOINT_PUSH_H_

#include "mavros_msgs/srv/detail/waypoint_push__struct.h"
#include "mavros_msgs/srv/detail/waypoint_push__functions.h"
#include "mavros_msgs/srv/detail/waypoint_push__type_support.h"

#endif  // MAVROS_MSGS__SRV__WAYPOINT_PUSH_H_
