// generated from rosidl_generator_c/resource/idl.h.em
// with input from geographic_msgs:msg\GeoPoint.idl
// generated code does not contain a copyright notice

#ifndef GEOGRAPHIC_MSGS__MSG__GEO_POINT_H_
#define GEOGRAPHIC_MSGS__MSG__GEO_POINT_H_

#include "geographic_msgs/msg/detail/geo_point__struct.h"
#include "geographic_msgs/msg/detail/geo_point__functions.h"
#include "geographic_msgs/msg/detail/geo_point__type_support.h"

#endif  // GEOGRAPHIC_MSGS__MSG__GEO_POINT_H_
