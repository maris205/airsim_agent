// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef GEOGRAPHIC_MSGS__MSG__GEO_POINT_HPP_
#define GEOGRAPHIC_MSGS__MSG__GEO_POINT_HPP_

#include "geographic_msgs/msg/detail/geo_point__struct.hpp"
#include "geographic_msgs/msg/detail/geo_point__builder.hpp"
#include "geographic_msgs/msg/detail/geo_point__traits.hpp"

#endif  // GEOGRAPHIC_MSGS__MSG__GEO_POINT_HPP_
