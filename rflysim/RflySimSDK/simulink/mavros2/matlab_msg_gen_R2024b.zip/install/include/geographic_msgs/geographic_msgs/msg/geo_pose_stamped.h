// generated from rosidl_generator_c/resource/idl.h.em
// with input from geographic_msgs:msg\GeoPoseStamped.idl
// generated code does not contain a copyright notice

#ifndef GEOGRAPHIC_MSGS__MSG__GEO_POSE_STAMPED_H_
#define GEOGRAPHIC_MSGS__MSG__GEO_POSE_STAMPED_H_

#include "geographic_msgs/msg/detail/geo_pose_stamped__struct.h"
#include "geographic_msgs/msg/detail/geo_pose_stamped__functions.h"
#include "geographic_msgs/msg/detail/geo_pose_stamped__type_support.h"

#endif  // GEOGRAPHIC_MSGS__MSG__GEO_POSE_STAMPED_H_
