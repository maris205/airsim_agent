// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef GEOGRAPHIC_MSGS__MSG__GEOGRAPHIC_MAP_HPP_
#define GEOGRAPHIC_MSGS__MSG__GEOGRAPHIC_MAP_HPP_

#include "geographic_msgs/msg/detail/geographic_map__struct.hpp"
#include "geographic_msgs/msg/detail/geographic_map__builder.hpp"
#include "geographic_msgs/msg/detail/geographic_map__traits.hpp"

#endif  // GEOGRAPHIC_MSGS__MSG__GEOGRAPHIC_MAP_HPP_
