// generated from rosidl_generator_c/resource/idl.h.em
// with input from geographic_msgs:msg\MapFeature.idl
// generated code does not contain a copyright notice

#ifndef GEOGRAPHIC_MSGS__MSG__MAP_FEATURE_H_
#define GEOGRAPHIC_MSGS__MSG__MAP_FEATURE_H_

#include "geographic_msgs/msg/detail/map_feature__struct.h"
#include "geographic_msgs/msg/detail/map_feature__functions.h"
#include "geographic_msgs/msg/detail/map_feature__type_support.h"

#endif  // GEOGRAPHIC_MSGS__MSG__MAP_FEATURE_H_
