// generated from rosidl_generator_c/resource/idl.h.em
// with input from geographic_msgs:msg\RouteNetwork.idl
// generated code does not contain a copyright notice

#ifndef GEOGRAPHIC_MSGS__MSG__ROUTE_NETWORK_H_
#define GEOGRAPHIC_MSGS__MSG__ROUTE_NETWORK_H_

#include "geographic_msgs/msg/detail/route_network__struct.h"
#include "geographic_msgs/msg/detail/route_network__functions.h"
#include "geographic_msgs/msg/detail/route_network__type_support.h"

#endif  // GEOGRAPHIC_MSGS__MSG__ROUTE_NETWORK_H_
