// generated from rosidl_generator_c/resource/idl.h.em
// with input from geographic_msgs:msg\RouteSegment.idl
// generated code does not contain a copyright notice

#ifndef GEOGRAPHIC_MSGS__MSG__ROUTE_SEGMENT_H_
#define GEOGRAPHIC_MSGS__MSG__ROUTE_SEGMENT_H_

#include "geographic_msgs/msg/detail/route_segment__struct.h"
#include "geographic_msgs/msg/detail/route_segment__functions.h"
#include "geographic_msgs/msg/detail/route_segment__type_support.h"

#endif  // GEOGRAPHIC_MSGS__MSG__ROUTE_SEGMENT_H_
