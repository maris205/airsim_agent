// generated from rosidl_generator_c/resource/idl.h.em
// with input from geographic_msgs:srv\GetGeoPath.idl
// generated code does not contain a copyright notice

#ifndef GEOGRAPHIC_MSGS__SRV__GET_GEO_PATH_H_
#define GEOGRAPHIC_MSGS__SRV__GET_GEO_PATH_H_

#include "geographic_msgs/srv/detail/get_geo_path__struct.h"
#include "geographic_msgs/srv/detail/get_geo_path__functions.h"
#include "geographic_msgs/srv/detail/get_geo_path__type_support.h"

#endif  // GEOGRAPHIC_MSGS__SRV__GET_GEO_PATH_H_
