// generated from rosidl_generator_c/resource/idl.h.em
// with input from geographic_msgs:srv\GetGeographicMap.idl
// generated code does not contain a copyright notice

#ifndef GEOGRAPHIC_MSGS__SRV__GET_GEOGRAPHIC_MAP_H_
#define GEOGRAPHIC_MSGS__SRV__GET_GEOGRAPHIC_MAP_H_

#include "geographic_msgs/srv/detail/get_geographic_map__struct.h"
#include "geographic_msgs/srv/detail/get_geographic_map__functions.h"
#include "geographic_msgs/srv/detail/get_geographic_map__type_support.h"

#endif  // GEOGRAPHIC_MSGS__SRV__GET_GEOGRAPHIC_MAP_H_
