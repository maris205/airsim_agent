// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:msg\CameraImageCaptured.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__CAMERA_IMAGE_CAPTURED_H_
#define MAVROS_MSGS__MSG__CAMERA_IMAGE_CAPTURED_H_

#include "mavros_msgs/msg/detail/camera_image_captured__struct.h"
#include "mavros_msgs/msg/detail/camera_image_captured__functions.h"
#include "mavros_msgs/msg/detail/camera_image_captured__type_support.h"

#endif  // MAVROS_MSGS__MSG__CAMERA_IMAGE_CAPTURED_H_
