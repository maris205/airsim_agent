// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__CAMERA_IMAGE_CAPTURED_HPP_
#define MAVROS_MSGS__MSG__CAMERA_IMAGE_CAPTURED_HPP_

#include "mavros_msgs/msg/detail/camera_image_captured__struct.hpp"
#include "mavros_msgs/msg/detail/camera_image_captured__builder.hpp"
#include "mavros_msgs/msg/detail/camera_image_captured__traits.hpp"

#endif  // MAVROS_MSGS__MSG__CAMERA_IMAGE_CAPTURED_HPP_
