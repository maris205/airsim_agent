// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:msg\DebugValue.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__DEBUG_VALUE_H_
#define MAVROS_MSGS__MSG__DEBUG_VALUE_H_

#include "mavros_msgs/msg/detail/debug_value__struct.h"
#include "mavros_msgs/msg/detail/debug_value__functions.h"
#include "mavros_msgs/msg/detail/debug_value__type_support.h"

#endif  // MAVROS_MSGS__MSG__DEBUG_VALUE_H_
