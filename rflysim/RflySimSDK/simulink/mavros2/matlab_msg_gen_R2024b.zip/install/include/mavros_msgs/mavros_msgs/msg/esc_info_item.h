// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:msg\ESCInfoItem.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__ESC_INFO_ITEM_H_
#define MAVROS_MSGS__MSG__ESC_INFO_ITEM_H_

#include "mavros_msgs/msg/detail/esc_info_item__struct.h"
#include "mavros_msgs/msg/detail/esc_info_item__functions.h"
#include "mavros_msgs/msg/detail/esc_info_item__type_support.h"

#endif  // MAVROS_MSGS__MSG__ESC_INFO_ITEM_H_
