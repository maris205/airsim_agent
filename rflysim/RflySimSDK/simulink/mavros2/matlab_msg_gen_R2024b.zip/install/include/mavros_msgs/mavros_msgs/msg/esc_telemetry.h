// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:msg\ESCTelemetry.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__ESC_TELEMETRY_H_
#define MAVROS_MSGS__MSG__ESC_TELEMETRY_H_

#include "mavros_msgs/msg/detail/esc_telemetry__struct.h"
#include "mavros_msgs/msg/detail/esc_telemetry__functions.h"
#include "mavros_msgs/msg/detail/esc_telemetry__type_support.h"

#endif  // MAVROS_MSGS__MSG__ESC_TELEMETRY_H_
