// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:msg\EstimatorStatus.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__ESTIMATOR_STATUS_H_
#define MAVROS_MSGS__MSG__ESTIMATOR_STATUS_H_

#include "mavros_msgs/msg/detail/estimator_status__struct.h"
#include "mavros_msgs/msg/detail/estimator_status__functions.h"
#include "mavros_msgs/msg/detail/estimator_status__type_support.h"

#endif  // MAVROS_MSGS__MSG__ESTIMATOR_STATUS_H_
