// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__GIMBAL_MANAGER_SET_PITCHYAW_HPP_
#define MAVROS_MSGS__MSG__GIMBAL_MANAGER_SET_PITCHYAW_HPP_

#include "mavros_msgs/msg/detail/gimbal_manager_set_pitchyaw__struct.hpp"
#include "mavros_msgs/msg/detail/gimbal_manager_set_pitchyaw__builder.hpp"
#include "mavros_msgs/msg/detail/gimbal_manager_set_pitchyaw__traits.hpp"

#endif  // MAVROS_MSGS__MSG__GIMBAL_MANAGER_SET_PITCHYAW_HPP_
