// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__GPSRTK_HPP_
#define MAVROS_MSGS__MSG__GPSRTK_HPP_

#include "mavros_msgs/msg/detail/gpsrtk__struct.hpp"
#include "mavros_msgs/msg/detail/gpsrtk__builder.hpp"
#include "mavros_msgs/msg/detail/gpsrtk__traits.hpp"

#endif  // MAVROS_MSGS__MSG__GPSRTK_HPP_
