// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__LOG_DATA_HPP_
#define MAVROS_MSGS__MSG__LOG_DATA_HPP_

#include "mavros_msgs/msg/detail/log_data__struct.hpp"
#include "mavros_msgs/msg/detail/log_data__builder.hpp"
#include "mavros_msgs/msg/detail/log_data__traits.hpp"

#endif  // MAVROS_MSGS__MSG__LOG_DATA_HPP_
