// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:msg\OpticalFlowRad.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__OPTICAL_FLOW_RAD_H_
#define MAVROS_MSGS__MSG__OPTICAL_FLOW_RAD_H_

#include "mavros_msgs/msg/detail/optical_flow_rad__struct.h"
#include "mavros_msgs/msg/detail/optical_flow_rad__functions.h"
#include "mavros_msgs/msg/detail/optical_flow_rad__type_support.h"

#endif  // MAVROS_MSGS__MSG__OPTICAL_FLOW_RAD_H_
