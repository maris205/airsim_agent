// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:msg\Tunnel.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__TUNNEL_H_
#define MAVROS_MSGS__MSG__TUNNEL_H_

#include "mavros_msgs/msg/detail/tunnel__struct.h"
#include "mavros_msgs/msg/detail/tunnel__functions.h"
#include "mavros_msgs/msg/detail/tunnel__type_support.h"

#endif  // MAVROS_MSGS__MSG__TUNNEL_H_
