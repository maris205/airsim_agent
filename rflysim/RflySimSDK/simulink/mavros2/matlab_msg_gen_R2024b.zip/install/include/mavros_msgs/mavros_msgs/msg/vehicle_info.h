// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:msg\VehicleInfo.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__VEHICLE_INFO_H_
#define MAVROS_MSGS__MSG__VEHICLE_INFO_H_

#include "mavros_msgs/msg/detail/vehicle_info__struct.h"
#include "mavros_msgs/msg/detail/vehicle_info__functions.h"
#include "mavros_msgs/msg/detail/vehicle_info__type_support.h"

#endif  // MAVROS_MSGS__MSG__VEHICLE_INFO_H_
