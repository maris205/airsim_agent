// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:msg\WheelOdomStamped.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__MSG__WHEEL_ODOM_STAMPED_H_
#define MAVROS_MSGS__MSG__WHEEL_ODOM_STAMPED_H_

#include "mavros_msgs/msg/detail/wheel_odom_stamped__struct.h"
#include "mavros_msgs/msg/detail/wheel_odom_stamped__functions.h"
#include "mavros_msgs/msg/detail/wheel_odom_stamped__type_support.h"

#endif  // MAVROS_MSGS__MSG__WHEEL_ODOM_STAMPED_H_
