// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:srv\CommandBool.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__COMMAND_BOOL_H_
#define MAVROS_MSGS__SRV__COMMAND_BOOL_H_

#include "mavros_msgs/srv/detail/command_bool__struct.h"
#include "mavros_msgs/srv/detail/command_bool__functions.h"
#include "mavros_msgs/srv/detail/command_bool__type_support.h"

#endif  // MAVROS_MSGS__SRV__COMMAND_BOOL_H_
