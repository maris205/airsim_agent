// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:srv\CommandLong.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__COMMAND_LONG_H_
#define MAVROS_MSGS__SRV__COMMAND_LONG_H_

#include "mavros_msgs/srv/detail/command_long__struct.h"
#include "mavros_msgs/srv/detail/command_long__functions.h"
#include "mavros_msgs/srv/detail/command_long__type_support.h"

#endif  // MAVROS_MSGS__SRV__COMMAND_LONG_H_
