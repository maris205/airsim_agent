// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:srv\CommandTriggerInterval.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__COMMAND_TRIGGER_INTERVAL_H_
#define MAVROS_MSGS__SRV__COMMAND_TRIGGER_INTERVAL_H_

#include "mavros_msgs/srv/detail/command_trigger_interval__struct.h"
#include "mavros_msgs/srv/detail/command_trigger_interval__functions.h"
#include "mavros_msgs/srv/detail/command_trigger_interval__type_support.h"

#endif  // MAVROS_MSGS__SRV__COMMAND_TRIGGER_INTERVAL_H_
