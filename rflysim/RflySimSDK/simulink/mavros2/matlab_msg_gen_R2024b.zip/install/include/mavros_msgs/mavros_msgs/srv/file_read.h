// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:srv\FileRead.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__FILE_READ_H_
#define MAVROS_MSGS__SRV__FILE_READ_H_

#include "mavros_msgs/srv/detail/file_read__struct.h"
#include "mavros_msgs/srv/detail/file_read__functions.h"
#include "mavros_msgs/srv/detail/file_read__type_support.h"

#endif  // MAVROS_MSGS__SRV__FILE_READ_H_
