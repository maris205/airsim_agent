// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:srv\GimbalManagerSetRoi.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__GIMBAL_MANAGER_SET_ROI_H_
#define MAVROS_MSGS__SRV__GIMBAL_MANAGER_SET_ROI_H_

#include "mavros_msgs/srv/detail/gimbal_manager_set_roi__struct.h"
#include "mavros_msgs/srv/detail/gimbal_manager_set_roi__functions.h"
#include "mavros_msgs/srv/detail/gimbal_manager_set_roi__type_support.h"

#endif  // MAVROS_MSGS__SRV__GIMBAL_MANAGER_SET_ROI_H_
