// generated from rosidl_generator_c/resource/idl.h.em
// with input from mavros_msgs:srv\VehicleInfoGet.idl
// generated code does not contain a copyright notice

#ifndef MAVROS_MSGS__SRV__VEHICLE_INFO_GET_H_
#define MAVROS_MSGS__SRV__VEHICLE_INFO_GET_H_

#include "mavros_msgs/srv/detail/vehicle_info_get__struct.h"
#include "mavros_msgs/srv/detail/vehicle_info_get__functions.h"
#include "mavros_msgs/srv/detail/vehicle_info_get__type_support.h"

#endif  // MAVROS_MSGS__SRV__VEHICLE_INFO_GET_H_
